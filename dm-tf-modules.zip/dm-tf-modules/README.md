# Dminds central IAC modules #

This repo is used to maintain all modules for our AWS infra build.
Please create your module and push to this repository 

### Naming conventiosn of modules and standards ###

* Create a module in your local environment
* Test and make sure you are happy with your module
* Create a pull request to add your module to this central storage 

### Sample module ###

* Referr to the `tf-ec2-module` module in this centralized module repo 
* 
