#!/bin/bash

#########################################

# Creating New EC2 
####################################




aws ec2 run-instances --image-id ami-0b850cf02cc00fdc8 --count 1 --instance-type t2.micro  --key-name "EC2 Tutorial"  --security-group-ids sg-03e7a1d7253b47753  --subnet-id subnet-fc6b54b4 --placement  AvailabilityZone="eu-west-1c" --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=cs-104-lesson6-michael}]'
 
