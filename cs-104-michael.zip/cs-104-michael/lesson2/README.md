# jenkins-pipeline-example

You can clone this repository to deploy using the JenkinsFile.

This repository will output .jat file after implementing this on your local machine 
or deploy the .jar file as artifact when using Jenkins pipeline.

Locally on the VM

use sudo mvn clean install
    sudo mvn package.
	
	
The Jenkinsfile in this repository is using Decalrative style


- Felix adding some extra info 